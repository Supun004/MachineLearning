from setuptools import setup

setup(name='data_prob_distributions',
      version='1.0',
      description='Gaussian and Binomial distributions',
      packages=['data_prob_distributions'],
      auther = 'Thilina Kariyawasam',
      zip_safe=False)
